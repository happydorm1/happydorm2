from fastapi import APIRouter

from app.api.v1 import admin, attachments, calendar, dashboard, documents, dormitory, event, event_requests, history, loan, notifications, payment, popup, reference, reports, schedule, spc, user

api_router = APIRouter(prefix="/api/v1")
api_router.include_router(user.router)
api_router.include_router(spc.router)
api_router.include_router(dormitory.router)
api_router.include_router(reference.router)
api_router.include_router(loan.router)
api_router.include_router(schedule.router)
api_router.include_router(event.router)
api_router.include_router(history.router)
api_router.include_router(payment.router)
api_router.include_router(documents.router)
api_router.include_router(calendar.router)
api_router.include_router(notifications.router)
api_router.include_router(dashboard.router)
api_router.include_router(popup.router)
api_router.include_router(admin.router)
api_router.include_router(event_requests.router)
api_router.include_router(reports.router)
api_router.include_router(history.events_router)
api_router.include_router(attachments.router)
