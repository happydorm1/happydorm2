Codespace가 켜진 뒤 터미널에서 딱 2번만 실행하면 됩니다.

1) 테이블 생성 + 관리자 계정 생성 (최초 1회)
python -c "from app.core.database import engine; from app.models.base import Base; from app.models import organization; Base.metadata.create_all(bind=engine)"
python -c "from app.core.database import SessionLocal; from app.core.security import hash_password; from app.models.organization import User, UserRole; db=SessionLocal(); db.add(User(name='관리자', email='admin@foundation.or.kr', role=UserRole.SYSTEM_ADMIN, hashed_password=hash_password('원하는비밀번호'))); db.commit()"

2) 서버 실행
uvicorn app.main:app --reload --host 0.0.0.0

실행 후 VS Code가 자동으로 띄워주는 포트 알림에서 8000번 포트를 열면 /docs 로 바로 접속됩니다.
